Ronderingshub v2 – offline webapp
==================================

Nyheter i v2
------------
- **Rapporter med logga & rubrik**: Lägg in org-namn och logotyp under *Inställningar*. Syns i utskrift/PDF.
- **Prioritet & förfallodatum** för problem: filtrera på prio och visa snabbt vad som är förfallet.
- **Kopiera** problemtext: snabb knapp för att dela i mejl/SMS/Teams.
- Polerad UI, förbättrad export (CSV), och allt fungerar **offline** via PWA.

Kom igång
---------
1) Öppna `index.html` i Chrome/Edge (mobil eller dator).
2) Inställningar → Lägg in fastigheter, org-namn och logotyp.
3) Lägg till på hemskärmen för app-känsla och offline.

Export & backup
---------------
- Exportera problem/ronderingar som CSV i respektive flik.
- Skriv ut rapport (med logga) via fliken **Rapporter**.
- Säkerhetskopiera/återställ under **Inställningar** (JSON).

Skapad: 2025-08-30
