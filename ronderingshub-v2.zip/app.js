/* Ronderingshub v2 – Adds org header, priority, due dates, share/copy */
(() => {
  const $ = (sel, el=document) => el.querySelector(sel);
  const $$ = (sel, el=document) => [...el.querySelectorAll(sel)];

  // IndexedDB
  const dbName = 'ronderingshub';
  let db;
  const openDB = () => new Promise((resolve, reject) => {
    const req = indexedDB.open(dbName, 2);
    req.onupgradeneeded = (e) => {
      const db = e.target.result;
      if(!db.objectStoreNames.contains('issues')){
        const s = db.createObjectStore('issues', { keyPath: 'id', autoIncrement: true });
        s.createIndex('by_prop', 'prop');
        s.createIndex('by_status', 'status');
        s.createIndex('by_area', 'area');
        s.createIndex('by_text', 'text');
        s.createIndex('by_date', 'createdAt');
      } else if (e.oldVersion < 2) {
        const s = req.transaction.objectStore('issues');
        s.createIndex('by_priority','priority');
        s.createIndex('by_due','dueDate');
      }
      if(!db.objectStoreNames.contains('rounds')){
        const s = db.createObjectStore('rounds', { keyPath: 'id', autoIncrement: true });
        s.createIndex('by_prop', 'prop');
        s.createIndex('by_date', 'date');
      }
      if(!db.objectStoreNames.contains('settings')){
        db.createObjectStore('settings', { keyPath: 'key' });
      }
    };
    req.onsuccess = () => { db = req.result; resolve(db); };
    req.onerror = () => reject(req.error);
  });

  const tx = (store, mode='readonly') => db.transaction(store, mode).objectStore(store);
  const setSetting = (key, val) => new Promise((res, rej) => {
    const r = tx('settings','readwrite').put({key, val});
    r.onsuccess = () => res(true); r.onerror = () => rej(r.error);
  });
  const getSetting = (key) => new Promise((res, rej) => {
    const r = tx('settings').get(key);
    r.onsuccess = () => res(r.result ? r.result.val : null);
    r.onerror = () => rej(r.error);
  });

  const addIssue = (issue) => new Promise((res, rej) => {
    const r = tx('issues','readwrite').add(issue);
    r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error);
  });
  const updateIssue = (issue) => new Promise((res, rej) => {
    const r = tx('issues','readwrite').put(issue);
    r.onsuccess = () => res(true); r.onerror = () => rej(r.error);
  });
  const deleteIssue = (id) => new Promise((res, rej) => {
    const r = tx('issues','readwrite').delete(id);
    r.onsuccess = () => res(true); r.onerror = () => rej(r.error);
  });
  const getAllIssues = () => new Promise((res, rej) => {
    const r = tx('issues').getAll();
    r.onsuccess = () => {
      const arr = r.result.sort((a,b)=>b.createdAt - a.createdAt);
      res(arr);
    };
    r.onerror = () => rej(r.error);
  });

  const addRound = (round) => new Promise((res, rej) => {
    const r = tx('rounds','readwrite').add(round);
    r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error);
  });
  const getAllRounds = () => new Promise((res, rej) => {
    const r = tx('rounds').getAll();
    r.onsuccess = () => res(r.result.sort((a,b)=>b.savedAt - a.savedAt));
    r.onerror = () => rej(r.error);
  });
  const clearAllData = () => new Promise((res, rej) => {
    const t = db.transaction(['issues','rounds','settings'], 'readwrite');
    t.objectStore('issues').clear();
    t.objectStore('rounds').clear();
    t.objectStore('settings').clear();
    t.oncomplete = () => res(true);
    t.onerror = () => rej(t.error);
  });

  // Helpers
  const fmtDate = (d) => new Date(d).toLocaleString('sv-SE', { dateStyle:'medium', timeStyle:'short' });
  const fmtDateOnly = (d) => new Date(d).toLocaleDateString('sv-SE');
  const todayISO = () => new Date().toISOString().slice(0,10);

  const el = {
    tabs: $$('.tab'),
    panels: $$('.panel'),
    r_prop: $('#r_prop'),
    r_date: $('#r_date'),
    checklist: $('#checklist'),
    progressBar: $('#progressBar'),
    r_notes: $('#r_notes'),
    resetChecklist: $('#resetChecklist'),
    saveRound: $('#saveRound'),
    roundsList: $('#roundsList'),
    roundsFilterProp: $('#roundsFilterProp'),

    i_form: $('#issueForm'),
    i_prop: $('#i_prop'),
    i_area: $('#i_area'),
    i_status: $('#i_status'),
    i_priority: $('#i_priority'),
    i_due: $('#i_due'),
    i_text: $('#i_text'),
    i_photo: $('#i_photo'),
    i_preview: $('#i_preview'),
    issuesList: $('#issuesList'),
    filterProp: $('#filterProp'),
    filterArea: $('#filterArea'),
    filterStatus: $('#filterStatus'),
    filterPriority: $('#filterPriority'),
    filterOverdue: $('#filterOverdue'),
    searchIssues: $('#searchIssues'),
    exportIssues: $('#exportIssues'),
    quickAddBtns: $('#quickAddBtns'),

    exportRounds: $('#exportRounds'),
    exportAllCsv: $('#exportAllCsv'),
    printReport: $('#printReport'),

    orgName: $('#orgName'),
    orgLogo: $('#orgLogo'),
    orgLogoPreview: $('#orgLogoPreview'),
    newProp: $('#newProp'),
    addProp: $('#addProp'),
    propsList: $('#propsList'),
    backupBtn: $('#backupBtn'),
    restoreFile: $('#restoreFile'),
    clearAll: $('#clearAll'),
    themeToggle: $('#themeToggle'),
    clock: $('#clock'),
  };

  function tickClock(){
    el.clock.textContent = new Date().toLocaleString('sv-SE', {weekday:'short', hour:'2-digit', minute:'2-digit', day:'2-digit', month:'2-digit'});
  }
  setInterval(tickClock, 30000);

  function setActiveTab(name){
    el.tabs.forEach(b => {
      const is = b.dataset.tab === name;
      b.classList.toggle('active', is);
      b.setAttribute('aria-selected', String(is));
    });
    el.panels.forEach(p => p.hidden = (p.id !== name));
    populatePropsSelects();
    renderIssues(); renderRounds();
  }
  function initTabs(){ el.tabs.forEach(btn => btn.addEventListener('click', () => setActiveTab(btn.dataset.tab))); }
  function initDate(){ el.r_date.value = todayISO(); }

  function updateProgress(){
    const boxes = $$('input[type=checkbox]', el.checklist);
    const done = boxes.filter(b => b.checked).length;
    const pct = Math.round(done / boxes.length * 100);
    if(el.progressBar){ el.progressBar.style.width = pct + '%'; el.progressBar.title = pct + '% klart'; }
  }
  function initChecklist(){
    el.checklist.addEventListener('change', updateProgress);
    el.resetChecklist.addEventListener('click', () => {
      $$('input[type=checkbox]', el.checklist).forEach(b => b.checked = false);
      el.r_notes.value='';
      updateProgress();
    });
    updateProgress();
  }

  // Settings: props/org
  async function getProps(){
    let props = await getSetting('props');
    if(!props){ props = ['Hus A', 'Hus B']; await setSetting('props', props); }
    return props;
  }
  async function addProp(){
    const v = el.newProp.value.trim();
    if(!v) return;
    const props = await getProps();
    props.push(v);
    await setSetting('props', props);
    el.newProp.value='';
    renderProps(); populatePropsSelects();
  }
  async function removeProp(idx){
    const props = await getProps();
    props.splice(idx,1);
    await setSetting('props', props);
    renderProps(); populatePropsSelects();
  }
  async function renderProps(){
    const props = await getProps();
    el.propsList.innerHTML = '';
    props.forEach((p, i) => {
      const div = document.createElement('div');
      div.className = 'item';
      div.innerHTML = `<div><strong>${p}</strong></div>
      <div class="row gap">
        <button class="btn small secondary" data-idx="${i}">Ta bort</button>
      </div>`;
      el.propsList.appendChild(div);
      $('button', div).addEventListener('click', () => removeProp(i));
    });
    const orgName = await getSetting('orgName') || '';
    el.orgName.value = orgName;
    const logo = await getSetting('orgLogo');
    if(logo){ el.orgLogoPreview.src = logo; el.orgLogoPreview.removeAttribute('aria-hidden'); }
  }
  async function populatePropsSelects(){
    const props = await getProps();
    const selects = [el.r_prop, el.i_prop, el.filterProp, el.roundsFilterProp];
    selects.forEach(sel => {
      const keepVal = sel.value;
      sel.innerHTML = sel === el.filterProp || sel === el.roundsFilterProp ? '<option value="">Alla fastigheter</option>' : '';
      props.forEach(p => {
        const opt = document.createElement('option');
        opt.textContent = p; opt.value = p;
        sel.appendChild(opt);
      });
      if(keepVal) sel.value = keepVal;
    });
  }

  function fileToDataURL(file){
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }
  async function compressImageDataUrl(dataUrl, maxW=1600){
    const img = new Image();
    return await new Promise((resolve) => {
      img.onload = () => {
        const scale = Math.min(1, maxW / img.width);
        const w = Math.round(img.width * scale);
        const h = Math.round(img.height * scale);
        const canvas = document.createElement('canvas');
        canvas.width = w; canvas.height = h;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, w, h);
        resolve(canvas.toDataURL('image/jpeg', 0.8));
      };
      img.src = dataUrl;
    });
  }

  function showQuickAdd(){
    const options = [
      'Trasig lampa i trapphus',
      'Läckande kran i tvättstuga',
      'Fel i bokningssystem',
      'Klotter i trapphus',
      'Nödljus trasigt',
      'Branddörr uppställd'
    ];
    const pick = prompt('Lägg till snabbt (skriv siffra):\n' + options.map((o,i)=>`${i+1}. ${o}`).join('\n'));
    const idx = parseInt(pick||'',10)-1;
    if(!isNaN(idx) && options[idx]){ el.i_text.value = options[idx]; }
  }

  // Issues
  let issuesCache = [];
  async function renderIssues(){
    issuesCache = await getAllIssues();
    const q = el.searchIssues.value.toLowerCase().trim();
    const p = el.filterProp.value;
    const a = el.filterArea.value;
    const s = el.filterStatus.value;
    const pr = el.filterPriority.value;
    const over = el.filterOverdue.checked;
    const today = todayISO();

    let list = issuesCache;
    if(q) list = list.filter(i => (i.text||'').toLowerCase().includes(q));
    if(p) list = list.filter(i => i.prop === p);
    if(a) list = list.filter(i => i.area === a);
    if(s) list = list.filter(i => i.status === s);
    if(pr) list = list.filter(i => i.priority === pr);
    if(over) list = list.filter(i => i.dueDate && i.dueDate < today && i.status !== 'Klart');

    el.issuesList.innerHTML = '';
    list.forEach(issue => {
      const card = document.createElement('div');
      card.className = 'issue-card';
      const statusClass = issue.status === 'Klart' ? 'green' : issue.status === 'Pågående' ? 'yellow' : 'red';
      const prioClass = issue.priority === 'Hög' ? 'high' : issue.priority === 'Låg' ? 'low' : '';
      const overdue = issue.dueDate && issue.dueDate < today && issue.status !== 'Klart';
      if(overdue) card.classList.add('overdue');
      card.innerHTML = `
        <header>
          <strong>${issue.prop} • ${issue.area}</strong>
          <div class="row gap">
            <span class="badge ${statusClass}">${issue.status}</span>
            <span class="badge prio ${prioClass}">Prio: ${issue.priority||'Normal'}</span>
          </div>
        </header>
        <div>${issue.text ? issue.text.replace(/\n/g,'<br>') : ''}</div>
        ${issue.photo ? `<img class="preview" src="${issue.photo}" alt="Foto på problem">` : ''}
        <small class="muted">${fmtDate(issue.createdAt)}${issue.dueDate?` • Senast: ${issue.dueDate}`:''}</small>
        <div class="issue-actions row gap">
          <select data-act="status" data-id="${issue.id}">
            <option ${issue.status==='Ej åtgärdat'?'selected':''}>Ej åtgärdat</option>
            <option ${issue.status==='Pågående'?'selected':''}>Pågående</option>
            <option ${issue.status==='Klart'?'selected':''}>Klart</option>
          </select>
          <button class="btn small secondary copy-btn" data-act="copy" data-id="${issue.id}">Kopiera</button>
          <button class="btn small secondary" data-act="delete" data-id="${issue.id}">Ta bort</button>
        </div>
      `;
      el.issuesList.appendChild(card);
    });
  }

  // Rounds
  let roundsCache = [];
  async function renderRounds(){
    roundsCache = await getAllRounds();
    const p = el.roundsFilterProp.value;
    let list = roundsCache;
    if(p) list = list.filter(r => r.prop === p);
    el.roundsList.innerHTML = '';
    list.forEach(r => {
      const div = document.createElement('div');
      div.className = 'item';
      const done = Object.values(r.checks||{}).filter(Boolean).length;
      const total = Object.keys(r.checks||{}).length;
      div.innerHTML = `
        <div>
          <strong>${r.prop||'-'}</strong> &nbsp; <small>${fmtDateOnly(r.date)} • ${done}/${total} punkter</small>
          <div class="muted">${(r.notes||'').slice(0,120)}</div>
        </div>
        <small>${fmtDate(r.savedAt)}</small>
      `;
      el.roundsList.appendChild(div);
    });
  }

  // CSV export helpers
  function toCSV(rows){
    const esc = (v) => ('"'+String(v).replace(/"/g,'""')+'"');
    const header = Object.keys(rows[0] || {}).join(',');
    const body = rows.map(r => Object.values(r).map(esc).join(',')).join('\n');
    return header + '\n' + body;
  }
  function downloadFile(name, data, type='text/csv'){
    const blob = new Blob([data], {type});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = name; a.click();
    setTimeout(()=>URL.revokeObjectURL(url), 1000);
  }

  // Wire up UI
  function wire(){
    // Tabs
    initTabs();

    // Theme
    const savedTheme = localStorage.getItem('theme') || 'dark';
    if(savedTheme === 'light') document.documentElement.classList.add('light');
    el.themeToggle.addEventListener('click', () => {
      document.documentElement.classList.toggle('light');
      localStorage.setItem('theme', document.documentElement.classList.contains('light') ? 'light' : 'dark');
    });

    // Rondering
    el.checklist.addEventListener('change', updateProgress);
    el.saveRound.addEventListener('click', async () => {
      const boxes = $$('input[type=checkbox]', el.checklist);
      const checks = {};
      boxes.forEach(b => checks[b.dataset.key] = b.checked);
      const round = {
        prop: el.r_prop.value || '',
        date: el.r_date.value || todayISO(),
        notes: el.r_notes.value.trim(),
        checks,
        savedAt: Date.now()
      };
      await addRound(round);
      boxes.forEach(b => b.checked = false);
      el.r_notes.value = '';
      updateProgress();
      renderRounds();
      alert('Rondering sparad.');
    });
    el.exportRounds.addEventListener('click', async () => {
      const rows = (await getAllRounds()).map(r => ({
        id: r.id,
        fastighet: r.prop,
        datum: r.date,
        sparad: new Date(r.savedAt).toISOString(),
        noteringar: r.notes || '',
        antal_klara: Object.values(r.checks||{}).filter(Boolean).length,
        antal_total: Object.keys(r.checks||{}).length
      }));
      if(!rows.length){ alert('Inga ronderingar ännu.'); return; }
      downloadFile('ronderingar.csv', toCSV(rows));
    });
    el.roundsFilterProp.addEventListener('change', renderRounds);

    // Issues form
    el.quickAddBtns.addEventListener('click', showQuickAdd);
    el.i_photo.addEventListener('change', async () => {
      const f = el.i_photo.files[0];
      if(!f){ el.i_preview.src=''; el.i_preview.removeAttribute('alt'); return; }
      const dataUrl = await fileToDataURL(f);
      const small = await compressImageDataUrl(dataUrl);
      el.i_preview.src = small;
      el.i_preview.alt = 'Förhandsvisning av foto';
      el.i_photo.dataset.dataurl = small;
    });
    el.i_form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const issue = {
        prop: el.i_prop.value,
        area: el.i_area.value,
        status: el.i_status.value,
        priority: el.i_priority.value || 'Normal',
        dueDate: el.i_due.value || '',
        text: el.i_text.value.trim(),
        photo: el.i_photo.dataset.dataurl || '',
        createdAt: Date.now()
      };
      if(!issue.prop || !issue.text){ alert('Välj fastighet och skriv en kort beskrivning.'); return; }
      await addIssue(issue);
      e.target.reset();
      el.i_preview.src=''; el.i_photo.dataset.dataurl='';
      renderIssues();
      alert('Problem sparat.');
    });

    // Issues list events
    el.issuesList.addEventListener('change', async (ev) => {
      const t = ev.target;
      if(t.dataset.act === 'status'){
        const id = Number(t.dataset.id);
        const issue = issuesCache.find(i => i.id === id);
        if(issue){
          issue.status = t.value;
          await updateIssue(issue);
          renderIssues();
        }
      }
    });
    el.issuesList.addEventListener('click', async (ev) => {
      const t = ev.target;
      const id = Number(t.dataset.id);
      if(t.dataset.act === 'delete'){
        if(confirm('Ta bort detta problem?')){
          await deleteIssue(id);
          renderIssues();
        }
      } else if (t.dataset.act === 'copy'){
        const issue = issuesCache.find(i => i.id === id);
        if(issue){
          const text = `[${issue.prop} • ${issue.area}] ${issue.text}\nStatus: ${issue.status} | Prio: ${issue.priority}${issue.dueDate?` | Senast: ${issue.dueDate}`:''}`;
          try{
            await navigator.clipboard.writeText(text);
            alert('Kopierat till Urklipp.');
          }catch{ alert('Kunde inte kopiera.'); }
        }
      }
    });

    // Filters
    [el.filterProp, el.filterArea, el.filterStatus, el.filterPriority].forEach(sel => sel.addEventListener('change', renderIssues));
    el.filterOverdue.addEventListener('change', renderIssues);
    el.searchIssues.addEventListener('input', renderIssues);
    el.exportIssues.addEventListener('click', async () => {
      const rows = (await getAllIssues()).map(i => ({
        id: i.id,
        tid: new Date(i.createdAt).toISOString(),
        fastighet: i.prop,
        omrade: i.area,
        status: i.status,
        prioritet: i.priority || 'Normal',
        forfallodatum: i.dueDate || '',
        beskrivning: i.text.replace(/\n/g, ' '),
        foto_dataurl: i.photo ? i.photo[:40] + '...' : ''
      }));
      if(!rows.length){ alert('Inga problem ännu.'); return; }
      downloadFile('problem.csv', toCSV(rows));
    });

    // Reports print + export all
    el.printReport.addEventListener('click', async () => {
      // Inject print header with org logo/name and timestamp
      const org = await getSetting('orgName') || '';
      const logo = await getSetting('orgLogo') || '';
      const tpl = $('#printHeaderTpl').content.cloneNode(true);
      if(logo){ tpl.querySelector('#printLogo').src = logo; }
      else { tpl.querySelector('#printLogo').style.display='none'; }
      tpl.querySelector('#printOrgName').textContent = org || 'Ronderingsrapport';
      tpl.querySelector('#printMeta').textContent = new Date().toLocaleString('sv-SE');
      document.body.prepend(tpl);
      window.print();
      // Remove after print? (Page reload re-renders anyway)
    });
    el.exportAllCsv.addEventListener('click', async () => {
      const issues = await getAllIssues();
      const rounds = await getAllRounds();
      const issuesRows = issues.map(i => ({
        id: i.id, tid: new Date(i.createdAt).toISOString(), fastighet: i.prop, omrade: i.area,
        status: i.status, prioritet: i.priority||'Normal', forfallodatum: i.dueDate||'',
        beskrivning: i.text.replace(/\n/g,' '), foto: i.photo ? '[dataurl]' : ''
      }));
      const roundsRows = rounds.map(r => ({
        id: r.id, fastighet: r.prop, datum: r.date, sparad: new Date(r.savedAt).toISOString(),
        noteringar: r.notes || '', antal_klara: Object.values(r.checks||{}).filter(Boolean).length,
        antal_total: Object.keys(r.checks||{}).length
      }));
      const content = 'issues.csv\n' + toCSV(issuesRows) + '\n\nrounds.csv\n' + toCSV(roundsRows);
      downloadFile('export_all.csv', content);
    });

    // Org settings
    el.orgName.addEventListener('change', () => setSetting('orgName', el.orgName.value.trim()));
    el.orgLogo.addEventListener('change', async () => {
      const f = el.orgLogo.files[0];
      if(!f) return;
      const dataUrl = await fileToDataURL(f);
      const small = await compressImageDataUrl(dataUrl, 600);
      await setSetting('orgLogo', small);
      el.orgLogoPreview.src = small;
      el.orgLogoPreview.removeAttribute('aria-hidden');
    });

    // Props + backup/restore
    el.addProp.addEventListener('click', addProp);
    el.backupBtn.addEventListener('click', async () => {
      const data = {
        props: await getProps(),
        issues: await getAllIssues(),
        rounds: await getAllRounds(),
        orgName: await getSetting('orgName'),
        orgLogo: await getSetting('orgLogo')
      };
      const blob = new Blob([JSON.stringify(data,null,2)], {type:'application/json'});
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url; a.download = 'ronderingshub-backup.json'; a.click();
      setTimeout(()=>URL.revokeObjectURL(url), 1000);
    });
    el.restoreFile.addEventListener('change', async () => {
      const f = el.restoreFile.files[0];
      if(!f) return;
      try{
        const text = await f.text();
        const data = JSON.parse(text);
        await clearAllData();
        if(data.props) await setSetting('props', data.props);
        if(data.orgName) await setSetting('orgName', data.orgName);
        if(data.orgLogo) await setSetting('orgLogo', data.orgLogo);
        if(Array.isArray(data.issues)){ for(const i of data.issues) await addIssue(i); }
        if(Array.isArray(data.rounds)){ for(const r of data.rounds) await addRound(r); }
        renderProps(); populatePropsSelects(); renderIssues(); renderRounds();
        alert('Backup återställd.');
      }catch(err){ alert('Kunde inte läsa backupfilen.'); console.error(err); }
    });
    el.clearAll.addEventListener('click', async () => {
      if(confirm('Är du säker? All lokal data raderas.')){
        await clearAllData();
        renderProps(); populatePropsSelects(); renderIssues(); renderRounds();
      }
    });

    // Init
    initDate(); initChecklist(); tickClock();
    renderProps(); populatePropsSelects();
    renderIssues(); renderRounds();
  }

  // PWA SW
  if('serviceWorker' in navigator){
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('sw.js').catch(console.warn);
    });
  }

  openDB().then(wire);
})();
